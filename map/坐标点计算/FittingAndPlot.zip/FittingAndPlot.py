# -*- coding: utf-8 -*-
# ---------------------------------------------------------------------------
# SmartMap.py
# Created on: 2014-09-01 22:00:00.00000
#   
# Description: 
# ---------------------------------------------------------------------------

import os
import math
import threading
import time
import datetime

import matplotlib.pyplot as plt
import math
import numpy as np
import random
import csv
plt.rcParams['font.sans-serif'] = ['SimHei']#设置显示中文
fig = plt.figure()
ax = fig.add_subplot(111)#将画布分割成1行1列，图像画在从左到右从上到下的第1块
#阶数为6阶
order=4
#生成曲线上的各个点
xa=[18.23522,23.13177,25.05091,29.55546,29.65541,30.56781,31.31974,36.63685,36.66124,39.46739,39.90609,43.89736,47.84907,50.24529]
ya=[21.97981,27.75185,29.99056,35.18512,35.29941,36.34007,37.1947,43.15613,43.18309,46.26669,46.74464,51.03908,55.19016,57.65537]
#
#xa = [75.99394, 88.13144, 91.12732, 101.74367,102.71344,106.5448, 109.51085,113.26015,114.30222,116.38543,116.9878, 121.62005,125.30672,127.50091]
#ya = [92.94103, 107.78534,111.44924,124.43305,125.61914,130.30516,133.93239,138.51779,139.79229,142.33976,143.07674,148.74201,153.2508,155.9343]

#数据筛选,去除盐度值为零的，提高拟合精度
i=0
x=[]
y=[]
for yy in ya:
  xx=xa[i]  
  x.append(math.cos(xx/90*math.pi))
  y.append(math.cos(yy/90*math.pi))
  i+=1
#绘制原始数据
ax.plot(x,y,label=u'原始',color='m',linestyle='',marker='.')
#计算多项式
coeffs=np.polyfit(x,y,order)#拟合多项式的系数存储在数组coeffs中

yy=np.polyval(coeffs,x)#根据多项式求函数值
#进行曲线绘制
#x_new=np.linspace(18, 60, 200)
x_new=np.linspace(0, 1, 200)
f_liner=np.polyval(coeffs,x_new)
#ax.plot(x,y,color='m',linestyle='',marker='.')
ax.plot(x_new,f_liner,label=u'拟合',color='g',linestyle='-',marker='')
# labels标签设置
#ax.set_xlim(18, 60)
ax.set_xlim(0, 1)
ax.set_xlabel(u'x')
ax.set_ylabel(u'y')
ax.set_title(u'X-Y', bbox={'facecolor':'0.8', 'pad':5})
ax.legend()
print(coeffs)
plt.show()

