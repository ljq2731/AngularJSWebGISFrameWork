L.TileLayer.SoGouMap = L.TileLayer.extend({
	/**
	*
	*/
    initialize: function (options) {
		//
		var url = "http://p{s}.go2map.com/seamless1/0/174/{z}/{blos}/{blas}/{x}_{y}.png";
		L.setOptions(this, options);
		L.TileLayer.prototype.initialize.call(this, url, options);
		
	},
	/**
	*
	*/
	/*
	getTileUrl: function (coords) {

		var tileBounds = this._tileCoordsToBounds(coords),
		    nw = this._crs.project(tileBounds.getNorthWest()),
		    se = this._crs.project(tileBounds.getSouthEast()),

		    bbox = (this._wmsVersion >= 1.3 && this._crs === L.CRS.EPSG4326 ?
			    [se.y, nw.x, nw.y, se.x] :
			    [nw.x, se.y, se.x, nw.y]).join(','),

		    url = L.TileLayer.prototype.getTileUrl.call(this, coords);

		return url +
			L.Util.getParamString(this.wmsParams, url, this.options.uppercase) +
			(this.options.uppercase ? '&BBOX=' : '&bbox=') + bbox;
		
		return L.Util.template(this._url, L.extend(data, this.options));
	}
	*/
	
	getTileUrl: function (tilePoint) { // (Point, Number) -> String

		var map = this._map;
		/*
		console.log("getZoom:  " + this._map.getZoom());
		console.log("getSize:  " + map.getSize());
		console.log("getSize:  " + map.getCenter());
		*/
		//console.log("getPixelBounds:  " + map.getPixelBounds().toBBoxString());
		//console.log("LatLngBounds:  " + map.getBounds().toBBoxString());
		
		var tileSize = this.options.tileSize;

		var nwPoint = tilePoint.multiplyBy(tileSize);
		var sePoint = nwPoint.add([tileSize, tileSize]);
			//
		this._crs = this.options.crs || this._map.options.crs;
		var nwLatLog = map.unproject(nwPoint, tilePoint.z);
		var seLatLog = map.unproject(sePoint, tilePoint.z);
		var nw = this._crs.project(nwLatLog);
		var se = this._crs.project(seLatLog);
		//console.log(tilePoint.x + "  " + tilePoint.y + "  " + tilePoint.z);
		//console.log(nwLatLog + "  " + seLatLog + "  " + nw + "  " + se);
		//
		var comWidth = 20037508.34279 * 2 / Math.pow(2, this._map.getZoom());
		var realWidth = se.x - nw.x;
		var xIndex = (nw.x + 20037508.34279) / realWidth;
		var yIndex = (20037508.34279 - nw.y) / realWidth;
		//console.log("x compare  " + tilePoint.x  + "  " + xIndex + "   y compare  " + tilePoint.y  + "  " + yIndex);
		
		//console.log("width:   " + comWidth + "  " + realWidth);
		//
		var zoom = this._map.getZoom();
		zoom = zoom - 1;
		var offsetX = Math.pow(2, zoom);
		var offsetY = offsetX - 1;

		var numX = tilePoint.x - offsetX;
		var numY = -tilePoint.y + offsetY;
		//console.log(tilePoint.x + "  " + tilePoint.y + "  " + offsetX + "  " + offsetY + "  " + numX + "  " + numY);
		
		//
		zoom = zoom + 1;
		
		var zoomLevel = 729 - (zoom+1);
		if (zoomLevel == 710)
		{
			zoomLevel = 792;
		}

		var blo = Math.floor(numX/100);
		var bla = Math.floor(numY/100);
		var blos="", blas="";
		if (blo < 0)
		{
			blos = "M" + (-blo);
		}
		else
		{
			blos = "" + blo;
		}

		if (bla < 0)
		{
			blas = "M" + (-bla);
		}
		else
		{
			blas = "" + bla;
		}

		var x = ("" + numX).replace("-","M"); 
		var y = ("" + numY).replace("-","M");

		//
		var url = L.Util.template(this._url, {s: 1, z:zoomLevel, blos:blos, blas:blas, x:x, y:y});
		//console.log("url: " + url);
		return url;
	}
});

L.tileLayer.soGouMap = function(options) {
    return new L.TileLayer.SoGouMap(options);
};


/******************************************************************** */
L.LabelIcon = L.Icon.extend({
	options: {
		//iconSize: [12, 12], // also can be set through CSS
		/*
		iconAnchor: (Point)
		popupAnchor: (Point)
		html: (String)
		bgPos: (Point)
		*/
		className: 'leaflet-div-icon',
        text: '',
		html: false
	},

	createIcon: function (oldIcon) {
		var div = (oldIcon && oldIcon.tagName === 'DIV') ? oldIcon : document.createElement('div'),
		    options = this.options;

			//div.style.position="absolute";

		//
		/*
		div.style.top="0px";
		div.style.left="0px";
		
		div.className = "gis-popover";
		var innerHTML =  '<div class="gis-arrow" style="left: 50%; "></div>'+
			    '<div class="gis-popover-content" style="">'+
					this.options.text+
			    '</div>';
		*/
		
		var innerHTML = '<div class="gis-popover" style="top: 0px; left: 0px; display: block;">'+
			    '<div class="gis-arrow" style="left: 50%; "></div>'+
			    '<div class="gis-popover-content" style="">'+
					this.options.text+
			    '</div>'+
		    '</div>';
		
		
		if (options.html !== false) {
			div.innerHTML = options.html;
		} else {			
			div.innerHTML = innerHTML;			
			//div.innerHTML = this.options.text;
		}

		if (options.bgPos) {
			div.style.backgroundPosition =
			        (-options.bgPos.x) + 'px ' + (-options.bgPos.y) + 'px';
		}
		/*
		if (typeof options.size === 'undefined')
		{
			console.log(options.size);
			var temp = document.body.appendChild(div);
			var size = temp.firstChild.getBoundingClientRect();
			this.options.size={"width":size.width, "height":size.height};			
			document.body.removeChild(temp);
		}*/
		//div.style.marginLeft = (-this.options.size.width/2) + 'px';
		
		//

		this._setIconStyles(div, 'icon');
		return div;
	},

    _setIconStyles: function (div, name) {
		var options = this.options,
		    size = L.point(options[name + 'Size']),
		    anchor;
console.log("size  " + size);
		if (name === 'shadow') {
			anchor = L.point(options.shadowAnchor || options.iconAnchor);
		} else {
			anchor = L.point(options.iconAnchor);
		}

		if (!anchor && size) {
			anchor = size.divideBy(2, true);
		}
		//div.className = 'leaflet-marker-' + name + ' ' + options.className;
		if (anchor) {
			console.log("size  " + size);
			console.log("anchor  " + anchor);
			div.style.marginLeft = (-anchor.x) + 'px';
			div.style.marginTop  = (-anchor.y) + 'px';
		}

		if (size) {
			div.style.width  = size.x + 'px';
			div.style.height = size.y + 'px';
		}
	},
	createShadow: function () {
		return null;
	}
});

L.labelIcon = function (options) {
	return new L.LabelIcon(options);
};