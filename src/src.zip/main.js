require([
    'angular',
    'bootstrap',
    'app'
], function (angular) {
    'use strict';
    $(document).ready(function () {
        angular.bootstrap(document, ['app']);
        $('html').addClass('ng-app: app');
    });
});