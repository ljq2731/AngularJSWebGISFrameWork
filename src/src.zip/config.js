'use strict';

require.config({
  baseUrl: '',

  map: {
    '*': {
      'css': 'lib/require-css/css' // or whatever the path to require-css is
    }
  },

  // alias libraries paths.  Must set 'angular'
  paths: {
    'jquery': 'lib/jquery/dist/jquery.min',
    'bootstrap': 'lib/bootstrap/dist/js/bootstrap.min',
    'angular': 'lib/angular/angular',
    'angular-resource': 'lib/angular-resource/angular-resource',
    'angular-animate': 'lib/angular-animate/angular-animate',
    'angular-block-ui': 'lib/angular-block-ui/dist/angular-block-ui',
    'angular-sanitize': 'lib/angular-sanitize/angular-sanitize',
    'angular-simple-logger': 'lib/angular-simple-logger/dist/angular-simple-logger',
    'ui-bootstrap': 'lib/angular-bootstrap/ui-bootstrap',
    'ui-bootstrap-tpls': 'lib/angular-bootstrap/ui-bootstrap-tpls',
    'angular-ui-router': 'lib/angular-ui-router/release/angular-ui-router',
    'ui-router-extras': 'lib/ui-router-extras/release/ct-ui-router-extras',
    'd3': 'lib/d3/d3',
    'async': 'lib/requirejs-plugins/src/async',
    'ocLazyLoad': 'lib/ocLazyLoad/dist/ocLazyLoad.require',
    'openlayers': 'lib/openlayers/dist/ol'
  },

  // Add angular modules that does not support AMD out of the box, put it in a shim
  shim: {
    'jquery': {
      exports: '$'
    },
    'openlayers': {
      exports: 'ol'
    },
    'bootstrap': ['jquery'],
    'angular': {
      deps: ['jquery'],
      exports: 'angular'
    },
    'angular-resource': ['angular'],
    'angular-animate': ['angular'],
    'angular-block-ui': {
      deps: ['angular'],
      exports: 'blockUI'
    },
    'angular-sanitize': ['angular'],
    'angular-simple-logger': ['angular'],
    'ui-bootstrap-tpls': ['angular'],
    'ui-bootstrap': ['angular', 'ui-bootstrap-tpls'],
    'd3': ['d3'],
    'angular-ui-router': ['angular'],
    'ui-router-extras':  ['angular-ui-router'],
    'ocLazyLoad':  ['angular']
  },

  // kick start application
  //deps: ['app','views/main/mapController']
  deps: ['main']
});