define([
  'angular',
  'angular-ui-router',
  'ui-router-extras',
  'ocLazyLoad',
], function (angular) {

  'use strict';
  var app = angular.module('app', ['ui.router', 'ct.ui.router.extras', 'oc.lazyLoad']);

  app.config(['$stateProvider', '$urlRouterProvider', '$ocLazyLoadProvider', '$futureStateProvider', function ($stateProvider, $urlRouterProvider, $ocLazyLoadProvider, $futureStateProvider) {

    var lazyDeferred;

    $ocLazyLoadProvider.config({
      debug: true,
      event: true,
      modules: [{
        name: 'baseInfo',
        serie: true,
        files: ['views/baseInfo/baseInfo.module.js', 'views/baseInfo/baseInfo.service.js', 'views/baseInfo/baseInfo.component.js']
      }, {
        name: 'baseInfoItem',
        serie: true,
        files: ['views/baseInfo/components/baseInfoItem/baseInfoItem.module.js', 'views/baseInfo/components/baseInfoItem/baseInfoItem.component.js']
      }, {
        name: 'monitor',
        serie: true,
        files: ['views/monitor/monitor.module.js', 'views/monitor/monitor.service.js', 'views/monitor/monitor.controller.js']
      }, {
        name: 'warn',
        serie: true,
        files: ['views/baseInfo/baseInfo.module.js', 'views/baseInfo/baseInfo.component.js']
      }, {
        name: 'gis',
        serie: true,
        rerun: true,
        reconfig: true,
        files: ['views/gis/gis.module.js', 'views/gis/gis.service.js', 'views/gis/gis.component.js']
      }, {
        name: 'openlayers',
        serie: true,
        //rerun: true,
        //reconfig: true,
        files: ['lib/openlayers/dist/ol.js']
      }]
    });

    $urlRouterProvider.otherwise('/monitor');

    $stateProvider
      .state('monitor', {
        url: '/monitor',
        templateUrl: 'views/monitor/monitor.html',
        controller: 'MonitorController',
        resolve: {
          load: function ($templateCache, $ocLazyLoad, $q) {
            var deferred = $q.defer();
            $ocLazyLoad.load('monitor').then(function (name) {
              deferred.resolve();
            }, function () {
              deferred.reject();
            });
            return deferred.promise;
            /*
            $ocLazyLoad.load({
              serie: true,
              files: ['views/monitor/monitor.controller.js']
            }).then(function (name) {
              deferred.resolve();
            }, function () {
              deferred.reject();
            });
            return deferred.promise;
            */
          }
        }
      })
      .state('baseInfo', {
        url: '/baseInfo',
        template: '<base-info></base-info>',
        resolve: {
          load: function ($templateCache, $ocLazyLoad, $q) {
            var deferred = $q.defer();
            $ocLazyLoad.load('baseInfo').then(function (name) {
              deferred.resolve();
            }, function () {
              deferred.reject();
            });
            return deferred.promise;
            /*
            $ocLazyLoad.load({
              serie: true,
              files: ['views/baseInfo/baseInfo.component.js']
            }).then(function (name) {
              deferred.resolve();
            }, function () {
              deferred.reject();
            });
            return deferred.promise;
            */
          }
        }
      })
      .state('warn', {
        url: '/warn',
        component: 'warn',
        resolve: {
          load: function ($templateCache, $ocLazyLoad, $q) {
            lazyDeferred = $q.defer();
            return $ocLazyLoad.load({
              files: ['views/warn/warnController']
            }).then(function () {
              lazyDeferred.resolve($templateCache.get('warn.html'));
            });
          }
        }
      })
      .state('gis', {
        url: '/gis',
        template: '<gis></gis>',
        resolve: {
          load: function ($templateCache, $ocLazyLoad, $q) {
            var deferred = $q.defer();
            $ocLazyLoad.load('gis').then(function (name) {
              deferred.resolve();
            }, function () {
              deferred.reject();
            });
            return deferred.promise;
          }
        }
      });

    //$locationProvider.html5Mode(true);
    console.log(" hello app !");
  }]);

  function BaseInfoController() {
    var self = this;
    self.message = 'Welcome to BaseInfo Page';
  }

  var baseInfo = {
    bindings: {},
    controller: BaseInfoController,
    templateUrl: 'views/baseInfo/baseInfo.html'
  };

  function AppController($scope, $state, $log) {
    var self = this;

    self.selectedItem = 'baseInfo';

    $scope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
      $log.debug('successfully changed states');
      $log.debug('event', event);
      $log.debug('toState', toState);
      $log.debug('toParams', toParams);
      $log.debug('fromState', fromState);
      $log.debug('fromParams', fromParams);
      self.selectedItem = toState.name;
    });

  }

  app.controller('appController', ['$scope', '$state', '$log', AppController]);

  return app;
});