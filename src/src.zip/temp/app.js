//L.Icon.Default.imagePath = "images";
var normalm = L.tileLayer.soGouMap({
			//tileSize: 128,
			maxZoom: 18
		});
		
		var map = L.map("mapid", {
			//crs:L.CRS.EPSG3857,
			crs:L.CRS.EPSG3857,
			center: [34.27147, 108.94249],
			zoom: 2,
			layers: [normalm],
			zoomControl: false
		});

		L.control.zoom({
			zoomInTitle: '放大',
			zoomOutTitle: '缩小'
		}).addTo(map);



		//L.marker([21.66264, 66.61867]).addTo(map).bindPopup("<b>Hello world!</b><br />I am a popup.").openPopup();
			
		/*
		console.log(gcj02_To_Bd09(34.27147, 108.94249));
		console.log(bd09_To_Gcj02(34.27147, 108.94249));
		//
		console.log(bd_encrypt(34.27147, 108.94249));
		console.log(bd_decrypt(34.27147, 108.94249));
		*/
		
		var popup = L.popup();

		function onMapClick(e) {
			popup
				.setLatLng(e.latlng)
				.setContent("You clicked the map at " + e.latlng.toString())
				.openOn(map);
		}
		
		map.on('click', onMapClick);
		
		//
		var latArr = [34.261, 39.90609, 29.55546, 30.56781, 18.23522, 50.24529, 47.84907, 39.46739, 29.65541, 36.63685, 43.89736, 25.05091, 23.13177, 36.66124, 31.31974];
		var logArr = [108.94235, 116.38543, 106.5448, 114.30222, 109.51085, 127.50091, 88.13144, 75.99394, 91.12732, 101.74367, 125.30672, 102.71344, 113.26015, 116.9878, 121.62005];
		//
		for(var i=0; i<latArr.length; i++)
		{			
			//var yLat = 1.11362669 * latArr[i] + 2.14347128;
			//var yLat = -0.00261773 * Math.pow(latArr[i], 2) + 1.2954873 * latArr[i] + -0.80282994;	
			var latTemp = Math.cos(latArr[i]/90.0*Math.PI);			
			var yLat = 0.00521972 * Math.pow(latTemp, 4) - 0.00891751 * Math.pow(latTemp, 3) + 0.22977745 * Math.pow(latTemp, 2) + 1.02298017 * latTemp -0.24894955;			
			yLat = Math.acos(yLat)/Math.PI*90;			
			//
			//var xLog = 1.22300355e0 * logArr[i] + 2.30782558e-4;
			var xLog = -8.43963327e-8 * Math.pow(logArr[i], 2) + 1.22302093 * logArr[i] + -6.44586540e-4
			console.log(yLat +  "   " + xLog);
			L.marker([yLat, xLog]).addTo(map);
		}


