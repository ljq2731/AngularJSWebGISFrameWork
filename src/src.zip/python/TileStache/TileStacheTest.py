import TileStache
import TileStache.MBTiles
import werkzeug
from werkzeug.serving import run_simple
from werkzeug.wrappers import Request, Response
configFile = "D:/Project/JavaScript/LeafletJS/LeafletWebGISDemo/src/python/TileStache/tilestache.cfg"
configFile = "D:\\Project\\JavaScript\\LeafletJS\\LeafletWebGISDemo\\src\\python\\TileStache\\tilestache.cfg"
#
configFile = "tilestache.cfg"


application = TileStache.WSGITileServer(configFile)
werkzeug.serving.run_simple('localhost', 8080, application)
'''
@Request.application
def application(request):
    return Response('Hello World!')

if __name__ == '__main__':
    from werkzeug.serving import run_simple
    run_simple('localhost', 4000, application)
'''
