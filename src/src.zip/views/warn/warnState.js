define(['angularAMD'], function (angularAMD) {
  'use strict';
  angularAMD.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {

    $stateProvider
      /*.state('warn.list', {
        url: '/list',
        controller: '',
        templateUrl: 'views/warn/module/list.html'
      })*/
      .state('warn.list', angularAMD.route({
            url: '/list',
            templateUrl: 'views/warn/module/list/list.html',
            controllerUrl: 'views/warn/warnController'
      }))
      .state('warn.search', {
        url: '/search',
        //controller: '',
        templateUrl: 'views/warn/module/search/search.html'
      })
      .state('warn.favorites', {
        url: '/favorites',
        controller: '',
        templateUrl: 'views/warn/module/favorite/favorite.html'
      })
    ;

    // Else -- This is not working for some reason:
    $urlRouterProvider.when('/warn', '/warn/list');

  }]);

});
