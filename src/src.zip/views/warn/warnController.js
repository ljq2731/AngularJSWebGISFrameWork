/*
define(['app', 'views/warn/warnState','views/warn/directive/stateName','leaflet', 'ui-leaflet'], function (app) {    
    'use strict';
    app.controller('WarnController', ['$scope', '$state','leafletData', 'leafletMapEvents', 'mapDivId',function ($scope, $state, leafletData, leafletMapEvents, mapDivId) {
        $scope.message = 'Comprehensive Warn List';
        console.log("mapDivId：  " + mapDivId);
        $state.transitionTo('warn.list');
        console.log("transitionTo:  " + 'warn.list');
    }]);
});
*/


define(['angularAMD','views/warn/warnState','views/warn/directive/stateName','leaflet', 'ui-leaflet'], function (angularAMD) {
  'use strict';
  angularAMD.controller('WarnController',['$scope', '$state','leafletData', 'leafletMapEvents', 'mapDivId',function ($scope, $state, leafletData, leafletMapEvents, mapDivId) {
        $scope.message = 'Comprehensive Warn List';
        console.log("mapDivId：  " + mapDivId);
        $state.transitionTo('warn.list');
        console.log("transitionTo:  " + 'warn.list');
    }]);
});



