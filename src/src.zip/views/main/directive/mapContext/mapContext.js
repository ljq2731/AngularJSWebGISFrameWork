define(['angularAMD','views/main/mapController'], function (angularAMD) {
  'use strict';
  //
  angularAMD.directive('mapContext', function () {
        return {
            restrict: 'A',
            controller: 'MapController',
            controllerAs: 'ctrl',
            templateUrl: 'views/main/directive/mapContext/mapContext.html'
        };
  });
});