define(['angularAMD',,'views/main/navMenuController'], function (angularAMD) {
  'use strict';
  angularAMD.directive('navMenu', [function ($state) {
    return {
      restrict: 'A',
      controller: 'NavMenuController',
      templateUrl: 'views/main/directive/navMenu/navMenu.html'
    };
  }]);
});

