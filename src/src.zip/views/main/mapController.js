define(['angularAMD', 'ui-bootstrap', 'ui-bootstrap-tpls', 'leaflet', 'ui-leaflet', 'PruneCluster', 'leaflet-draw', 'TileLayerSogou', 'leaflet-pulse-icon', 'leaflet.label'], function (angularAMD) {
    angularAMD.controller('MapController', ['$scope', '$window', 'leafletData', 'leafletMapEvents', 'mapDivId', '$uibModal', function ($scope, $window, leafletData, leafletMapEvents, mapDivId, $uibModal) {
        'use strict';
        var self = this;
        var mapId = mapDivId;
        console.log("mapId:  mapComponent = " + mapId);
        //
        //this.initMap = function ($scope) {
        angular.extend($scope, {
            center: {
                lat: 40.51061,
                lng: 133.23708,
                zoom: 4
            },
            markers: {},
            controls: {
                draw: {
                    draw: {
                        polygon: false,
                        circle: false,
                        rectangle: false
                    }
                }
            },
            layers: {
                baselayers: {
                    sogou: {
                        name: 'SoGouMap',
                        type: 'soGouTiles',
                        layerOptions: {
                            showOnSelector: false,
                            maxZoom: 18
                        }
                    }
                },
                overlays: {
                    draw: {
                        name: 'draw',
                        type: 'group',
                        visible: true,
                        layerParams: {
                            showOnSelector: false
                        }
                    }
                }
            }
        });
        //

        $scope.$on('leafletDirectiveMap.' + mapId + '.load', function (event) {
            console.log("map event: " + event.name);
            //$scope.eventDetected = event.name;
            //self.initializeMap($scope);
            self.loadFeature($scope);
            self.drawHandle($scope);
        });

        //
        $scope.$on('leafletDirectiveMap.' + mapId + '.click', function (event) {
            console.log("map event: " + event.name);
            //$scope.eventDetected = event.name;
            //self.initializeMap($scope);
            self.showSearchMore = false;
        });

        //};

        this.drawHandle = function ($scope) {
            leafletData.getMap(mapId).then(function (map) {
                leafletData.getLayers(mapId).then(function (baselayers) {
                    var drawnItems = baselayers.overlays.draw;
                    map.on('draw:created', function (e) {
                        var layer = e.layer;
                        drawnItems.addLayer(layer);
                        console.log(JSON.stringify(layer.toGeoJSON()));
                    });
                });
                //
            }, function (e) {
                console.log(e);
            });
        };


        this.showEvent = function ($scope) {
            $scope.eventDetected = "No events yet...";
            var mapEvents = leafletMapEvents.getAvailableMapEvents();
            for (var k in mapEvents) {
                var eventName = 'leafletDirectiveMap.mapComponent.' + mapEvents[k];
                $scope.$on(eventName, function (event) {
                    console.log("map event: " + event.name);
                    $scope.eventDetected = event.name;
                });
            };
        };


        this.loadFeature = function ($scope) {
            leafletData.getMap(mapId).then(function (map) {
                console.log("------------------------------------------------------------------------------------");
                var pruneClusterLayer = new PruneClusterForLeaflet();

                
                var prepareLeafletMarkerSuper = pruneClusterLayer.PrepareLeafletMarker;
                pruneClusterLayer.PrepareLeafletMarker = function(leafletMarker, data, category) {
                    //prepareLeafletMarkerSuper(leafletMarker, data, category);
                    //
                    if(data.type == 1)
                    {
                        var icon = L.icon.pulse({
                            iconSize: [20, 20],
                            color: 'red'
                        });
                        leafletMarker.setIcon(icon);
                    }
                    else{
                        var icon = L.labelIcon({text: 'labelIcon'+Math.random()});   
                        if(leafletMarker.options.iconSize)
                        {
                            console.log("-----------------<><><><><>");
                            icon = L.labelIcon({text: 'labelIcon'+Math.random(), 'iconSize':leafletMarker.options.iconSize});   
                        }                     
                        leafletMarker.setIcon(icon);
                        //marker.data.size = marker.data.icon.options.size;
                        //
                        leafletMarker.on('add', function (e) {
                            console.log(e.target._icon);
                            console.log(e.target._icon.firstChild.getBoundingClientRect());
                            var rect = e.target._icon.firstChild.getBoundingClientRect();
                            //
                            leafletMarker.options.iconSize==[rect.width, rect.height];

                            //
                            leafletMarker.options.icon.options.iconSize=[rect.width, rect.height];
                            console.log(e.target._icon.firstChild.marginLeft);
                            e.target._icon.firstChild.style.marginLeft = (-rect.width / 2) + 'px';
                            //
                            //e.target._icon.marginLeft = (-rect.width / 2) + 'px';

                            //
                            //console.log(e.target._icon.firstChild.marginLeft);
                            //leafletMarker.setIcon(e.target._icon);
                            //leafletMarker.update();
                        });
                    }
                    //

                    
                };
                


                var size = 10000;
                var markers = [];
                for (var i = 0; i < size; ++i) {
                    var marker = new PruneCluster.Marker(40.51061 + (Math.random() - 0.5) * Math.random() * 0.00001 * size, 133.23708 + (Math.random() - 0.5) * Math.random() * 0.00002 * size);
                    //._icon
                    //
                    if(i>90 && i<5000)
                    {
                        marker.data.type = 1;
                    }
                    else{
                        marker.data.type = 2;
                    }
                    //
                    markers.push(marker);
                    pruneClusterLayer.RegisterMarker(marker);
                }
                //
                var marker = new PruneCluster.Marker(40, 135);
                    // var icon = L.labelIcon({text: 'labelIcon123'+Math.random()});                        
                    marker.data.type = 2;
                    markers.push(marker);
                    pruneClusterLayer.RegisterMarker(marker);

                    var markerWarn = L.marker([40, 135]).addTo(map);

                /*
                window.setInterval(function () {
                    for (i = 0; i < size / 2; ++i) {
                        var coef = i < size / 8 ? 10 : 1;
                        var ll = markers[i].position;
                        ll.lat += (Math.random() - 0.5) * 0.00001 * coef;
                        ll.lng += (Math.random() - 0.5) * 0.00002 * coef;
                    }

                    pruneClusterLayer.ProcessView();
                }, 500);
                */

                map.addLayer(pruneClusterLayer);
                
                /*
                //
                var pulsingIcon = L.icon.pulse({
                    iconSize: [20, 20],
                    color: 'red'
                });
                */

                 


                /*
                var markerWarn = L.marker([40, 133], {
                    icon: pulsingIcon
                }).addTo(map);
                L.marker([40.3, 133.3]).bindLabel('Leaflet.label', {
                    noHide: true
                }).addTo(map);
                //
                */

                /*
                    var myIcon = L.labelIcon({text: 'labelIcon'});
                    L.marker([40.3, 138.3], {icon: myIcon}).addTo(map);
                    L.marker([40.3, 138.3]).addTo(map);
                */
                //
            }, function (e) {
                console.log(e);
            });
        };

        this.initializeMap = function ($scope) {
            console.log("initializeMap!");
            var latArr = [34.261, 39.90609, 29.55546, 30.56781, 18.23522, 50.24529, 47.84907, 39.46739, 29.65541, 36.63685, 43.89736, 25.05091, 23.13177, 36.66124, 31.31974];
            var logArr = [108.94235, 116.38543, 106.5448, 114.30222, 109.51085, 127.50091, 88.13144, 75.99394, 91.12732, 101.74367, 125.30672, 102.71344, 113.26015, 116.9878, 121.62005];
            //
            var markers = {};
            for (var i = 0; i < latArr.length; i++) {
                var latTemp = Math.cos(latArr[i] / 90.0 * Math.PI);
                var yLat = 0.00521972 * Math.pow(latTemp, 4) - 0.00891751 * Math.pow(latTemp, 3) + 0.22977745 * Math.pow(latTemp, 2) + 1.02298017 * latTemp - 0.24894955;
                yLat = Math.acos(yLat) / Math.PI * 90;
                //
                var xLog = -8.43963327e-8 * Math.pow(logArr[i], 2) + 1.22302093 * logArr[i] + -6.44586540e-4;
                console.log(yLat + "   " + xLog);
                markers["p" + i] = {
                    lat: yLat,
                    lng: xLog
                }
            }
            //
            angular.extend($scope, {
                markers: markers
            });
        };
        //
        //
        //

        $('.menu > ul > li:has( > ul)').addClass('menu-dropdown-icon');

        $('.menu > ul > li > ul:not(:has(ul))').addClass('normal-sub');

        /*
        $(".menu > ul > li").hover(function (e) {
            if ($(window).width() > 943) {
                $(this).children("ul").stop(true, false).fadeToggle(150);
                e.preventDefault();
            }
        });

        $(".menu > ul > li").click(function (e) {
            if ($(window).width() <= 943) {
                $(this).children("ul").fadeToggle(150);
                e.preventDefault();
            }
        });
        */

        this.hoverNews = false;
        this.showNews = function ($scope) {
            console.log("true");
            self.hoverNews = true;
        };

        this.hidenNews = function ($scope) {
            console.log("false");
            self.hoverNews = false;
        };
        //
        this.hoverContact = false;
        this.showContact = function ($scope) {
            console.log("true");
            self.hoverContact = true;
        };

        this.hidenContact = function ($scope) {
            console.log("false");
            self.hoverContact = false;
        };


        /***************************************************************** */
        this.searchText = "";
        this.showSearchMore = false;
        this.maxSize = 6;
        this.bigCurrentPage = 7;
        this.searchResultNetElementArray = [{
            'id': 'GSM001',
            'name': 'GSM网元1',
            'x': 33.2,
            'y': 133.5,
            'ip': '10.123.56.85',
            'neType': 'GSM',
            'homeSub': 'aaaaaa',
            'neStaus': 'connect'
        }, {
            'id': 'UTMS001',
            'name': 'UTMS网元1',
            'x': 33.1,
            'y': 133.3,
            'ip': '141.123.56.85',
            'neType': 'UTMS',
            'homeSub': 'bbbsdf',
            'neStaus': 'unconnect'
        }, {
            'id': 'FDD001',
            'name': 'FDD网元1',
            'x': 33.13,
            'y': 133.6,
            'ip': '13.123.56.85',
            'neType': 'FDD',
            'homeSub': 'yui',
            'neStaus': 'connect'
        }, {
            'id': 'TDD001',
            'name': 'TDD网元1',
            'x': 33.23,
            'y': 133.2,
            'ip': '101.123.56.85',
            'neType': 'TDD',
            'homeSub': 'dffg',
            'neStaus': 'connect'
        }, {
            'id': 'WCDMA001',
            'name': 'WCDMA网元1',
            'x': 33.33,
            'y': 133.42,
            'ip': '141.123.56.85',
            'neType': 'WCDMA',
            'homeSub': 'jklu',
            'neStaus': 'connect'
        }, {
            'id': 'CDMA001',
            'name': 'CDMA网元1',
            'x': 33.02,
            'y': 133.7,
            'ip': '182.123.56.85',
            'neType': 'CDMA',
            'homeSub': 'hjk',
            'neStaus': 'connect'
        }, {
            'id': 'CDMA200001',
            'name': 'CDMA200网元1',
            'x': 33.06,
            'y': 133.36,
            'ip': '230.123.56.85',
            'neType': 'CDMA',
            'wrr': 'aaaaaa',
            'neStaus': 'unconnect'
        }, {
            'id': 'FDD002',
            'name': 'FDD网元2',
            'x': 33.12,
            'y': 133.57,
            'ip': '45.123.56.85',
            'neType': 'FDD',
            'homeSub': 'uouou',
            'neStaus': 'connect'
        }, {
            'id': 'TDCDMA001',
            'name': 'TDCDMA网元1',
            'x': 33.18,
            'y': 133.64,
            'ip': '153.123.56.85',
            'neType': 'TDCDMA',
            'xvxv': 'aaaaaa',
            'neStaus': 'unknown'
        }, {
            'id': 'GSM002',
            'name': 'GSM网元2',
            'x': 33.26,
            'y': 133.29,
            'ip': '142.123.56.85',
            'neType': 'GSM',
            'homeSub': 'trytu',
            'neStaus': 'connect'
        }];
        //
        this.cleanHandle = function ($scope) {
            console.log("------clean--------");
            self.searchText = "";
            console.log("------clean--------");
        };
        //
        this.searchClickHandle = function ($scope) {
                self.showSearchMore = true;
            }
            //
        this.searchHandle = function () {
            //this.searchText = "";
        };
        //
        this.modalData = {};
        this.showDetail = function (id) {
            //this.searchText = "";
            console.log(id);
            //var newWindowRef = $window.open("http://www.sina.com.cn", "New Window", "width=1280,height=890,resizable=1");
            //
            self.modalData.neid = id;
            console.log($uibModal);
            var modalInstance = $uibModal.open({
                templateUrl: 'views/main/directive/mapContext/detail.html',
                controller: 'ModalInstanceCtrl',
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                controllerAs: 'ctrl',
                resolve: {
                    modalData: function () {
                        return self.modalData;
                    }
                }
            });
            modalInstance.opened.then(function () { // 模态窗口打开之后执行的函数  
                console.log('modal is opened');
            });
            modalInstance.result.then(function (result) {
                console.log(result);
            }, function (reason) {
                console.log(reason); // 点击空白区域，总会输出backdrop  
                // click，点击取消，则会暑促cancel  
                console.log('Modal dismissed at: ' + new Date());
            });
        };

    }]);

    angularAMD.controller('ModalInstanceCtrl', ['$scope', '$uibModalInstance', 'modalData', function ($scope, $uibModalInstance, modalData) {
        'use strict';
        console.log($uibModalInstance);
        console.log(modalData);

        this.message = 'Shows a list of monitors';
        this.monitorInfos = modalData.neid;
        this.selected = {
            item: modalData.neid
        };
        this.ok = function () {
            $uibModalInstance.close(this.selected);
        };
        this.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);

});



/*
angular.module('ui.bootstrap.demo').controller('ModalDemoCtrl1', function ($uibModal, $log, $document) {
    var $ctrl = this;
    $ctrl.items = ['item1', 'item2', 'item3'];

    $ctrl.animationsEnabled = true;

    $ctrl.open = function (size, parentSelector) {
        var parentElem = parentSelector ?
            angular.element($document[0].querySelector('.modal-demo ' + parentSelector)) : undefined;
        var modalInstance = $uibModal.open({
            animation: $ctrl.animationsEnabled,
            ariaLabelledBy: 'modal-title',
            ariaDescribedBy: 'modal-body',
            templateUrl: 'myModalContent.html',
            controller: 'ModalInstanceCtrl',
            controllerAs: '$ctrl',
            size: size,
            appendTo: parentElem,
            resolve: {
                items: function () {
                    return $ctrl.items;
                }
            }
        });

        modalInstance.result.then(function (selectedItem) {
            $ctrl.selected = selectedItem;
        }, function () {
            $log.info('Modal dismissed at: ' + new Date());
        });
    };

    $ctrl.openComponentModal = function () {
        var modalInstance = $uibModal.open({
            animation: $ctrl.animationsEnabled,
            component: 'modalComponent',
            resolve: {
                items: function () {
                    return $ctrl.items;
                }
            }
        });

        modalInstance.result.then(function (selectedItem) {
            $ctrl.selected = selectedItem;
        }, function () {
            $log.info('modal-component dismissed at: ' + new Date());
        });
    };

    $ctrl.openMultipleModals = function () {
        $uibModal.open({
            animation: $ctrl.animationsEnabled,
            ariaLabelledBy: 'modal-title-bottom',
            ariaDescribedBy: 'modal-body-bottom',
            templateUrl: 'stackedModal.html',
            size: 'sm',
            controller: function ($scope) {
                $scope.name = 'bottom';
            }
        });

        $uibModal.open({
            animation: $ctrl.animationsEnabled,
            ariaLabelledBy: 'modal-title-top',
            ariaDescribedBy: 'modal-body-top',
            templateUrl: 'stackedModal.html',
            size: 'sm',
            controller: function ($scope) {
                $scope.name = 'top';
            }
        });
    };

    $ctrl.toggleAnimation = function () {
        $ctrl.animationsEnabled = !$ctrl.animationsEnabled;
    };
});

// Please note that $uibModalInstance represents a modal window (instance) dependency.
// It is not the same as the $uibModal service used above.

angular.module('ui.bootstrap.demo').controller('ModalInstanceCtrl1', function ($uibModalInstance, items) {
    var $ctrl = this;
    $ctrl.items = items;
    $ctrl.selected = {
        item: $ctrl.items[0]
    };

    $ctrl.ok = function () {
        $uibModalInstance.close($ctrl.selected.item);
    };

    $ctrl.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
});

// Please note that the close and dismiss bindings are from $uibModalInstance.

angular.module('ui.bootstrap.demo').component('modalComponent1', {
    templateUrl: 'myModalContent.html',
    bindings: {
        resolve: '<',
        close: '&',
        dismiss: '&'
    },
    controller: function () {
        var $ctrl = this;

        $ctrl.$onInit = function () {
            $ctrl.items = $ctrl.resolve.items;
            $ctrl.selected = {
                item: $ctrl.items[0]
            };
        };

        $ctrl.ok = function () {
            $ctrl.close({
                $value: $ctrl.selected.item
            });
        };

        $ctrl.cancel = function () {
            $ctrl.dismiss({
                $value: 'cancel'
            });
        };
    }
});
*/