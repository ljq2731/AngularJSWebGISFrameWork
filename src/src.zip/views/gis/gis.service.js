  (function (angular) {

      'use strict';

      /**
       * @Injector
       */
      function GisService() {
          var self = this;          
          var thisIsPrivate = "Private";

          self.variable = "This is public";
          
          self.getPrivate = function () {
              return thisIsPrivate;
          };

      }


      /**
       * @Inject
       */
      angular.module('gis').service('GisService', GisService);

      console.log("gis  Service !");

  })(angular);