define( ['openlayers'],function (ol) {

    'use strict';

    /**
     * @ngInject
     */
    function GisController() {
        var self = this;
        self.message = 'Welcome to gis Page';
        self.$onInit = $onInit;

        var map = null;

        function $onInit() {
            //
            console.log("adddd");
            //
            map = new ol.Map({
                layers: [
                    new ol.layer.Tile({
                        source: new ol.source.OSM()
                    })
                ],
                target: 'map',
                view: new ol.View({
                    center: [0, 0],
                    zoom: 2
                })
            });
            //
            addFeatureLayer();
            
        }

        function addFeatureLayer() {
            var count = 200;
            var features = new Array(count);
            var e = 4500000;
            for (var i = 0; i < count; ++i) {
                var coordinates = [2 * e * Math.random() - e, 2 * e * Math.random() - e];
                features[i] = new ol.Feature(new ol.geom.Point(coordinates));
            }

            var source = new ol.source.Vector({
                features: features
            });

            var clusterLayer = new ol.layer.Vector({
                source: source,
                style: function (feature) {
                    //
                    var iconStyle = new ol.style.Style({
                        image: new ol.style.Icon(({
                            imgSize: [20, 20],
                            src: 'http://openlayers.org/assets/theme/img/logo70.png'
                        }))
                    });
                    return iconStyle;

                    // var styleValue = new ol.style.Style({
                    //     image: new ol.style.Circle({
                    //         radius: 10,
                    //         stroke: new ol.style.Stroke({
                    //             color: '#fff'
                    //         }),
                    //         fill: new ol.style.Fill({
                    //             color: '#3399CC'
                    //         })
                    //     }),
                    //     text: new ol.style.Text({
                    //         text: '123',
                    //         fill: new ol.style.Fill({
                    //             color: '#fff'
                    //         })
                    //     })
                    // });
                    // return styleValue;
                }
            });
            //
            map.addLayer(clusterLayer);
        }
    }

    var gis = {
        bindings: {},
        controller: GisController,
        templateUrl: 'views/gis/gis.html'
    };

    angular.module('gis').component('gis', gis, []);

    console.log("Welcome gis component");

});