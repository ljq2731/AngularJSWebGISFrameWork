(function (angular) {
    'use strict';
    //require(["lib/openlayers/dist/ol"]);

    var gis =  angular.module('gis', []); // 
    
    console.log("Hello gis module !");
    
 })(angular);