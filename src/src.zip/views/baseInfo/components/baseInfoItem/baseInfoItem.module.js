(function (angular) {
    'use strict';

    angular.module('baseInfoItem',[]);
    
    console.log("Hello baseInfoItem module !");
    
})(angular);