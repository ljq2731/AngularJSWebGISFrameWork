(function (angular) {
    'use strict';

    var baseInfo =  angular.module('baseInfo',['baseInfoItem']);
    
    console.log("Hello baseInfo module !");
    
})(angular);