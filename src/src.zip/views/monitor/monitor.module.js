define([
    'angular',
], function () {
    'use strict';
    var monitor = angular.module('monitor',[]);
    
    console.log("Hello monitor module !");
});